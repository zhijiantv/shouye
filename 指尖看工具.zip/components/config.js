//公共的接口地址
module.exports={
  host:'https://kangj.netlify.app/',
  localDataUrl:'/localData.json',
  searchUrl:'/search.json',//搜索列表接口

//    indexDetail:'/id/1001',//首页详情数据
 
}
