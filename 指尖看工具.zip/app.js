// app.js
App({

  
  //封装小程序网络请求--------
  http(url,that,arr){
    wx.request({
      url:url,
     success:(res)=>{
        console.log(res.data);
          that.setData({
            [arr]:res.data.data
          })
        }         
    })
  },  



})
