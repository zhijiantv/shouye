// pages/index/index.js
//导入外部的模块js
const {host,searchUrl}=require('../../components/config')
const app=getApp()
// 在页面中定义激励视频广告

Page({
  //全局广告设置
  videoAd:null,
  /**
   * 页面的初始数据
   */
  data: {
     height:'',//屏幕高度
     showPopup: false,
     listArr:[],//列表数据
     originalList: [],    // 原始数据
     searchText: '' ,      // 搜索关键词
     noticeText: "加载中..." // 默认公告内容     
  },

 
  onLoad:function(options) {
   // 在页面onLoad回调事件中创建激励视频广告实例
   if (wx.createRewardedVideoAd) {
    this.videoAd = wx.createRewardedVideoAd({
      adUnitId: 'adunit-4a3f07fffad263f5'
    })
    this.videoAd.onLoad(() => {})
    this.videoAd.onError((err) => {
      console.error('激励视频光告加载失败', err)
    })
    this.videoAd.onClose((res) => {
          console.log(res.isEnded)
      if(res.isEnded){
        this.setData({
          showPopup: true,
        })
       }else{
        wx.showToast({
          title:'无法获取',
   })
      }
  })
  }
  
    //2.请求网络数据轮播图-------
   // this.http(host+bannerUrl,'bannerArr')
   //获取app.js封装的网络请求------------
//    app.http(host+bannerUrl,this,'bannerArr')
//     wx.request({
//    url:host+bannerUrl,
//      success:(res)=>{
//         console.log(res.data);
//           this.setData({
//             bannerUrl:res.data.data
//           })
//         }         
//      })

          //3.首页列表数据----------
     //this.http(host+indexUrl,'listArr')

     wx.request({
      url: host+searchUrl,
      success: res => {
        this.setData({ 
          originalList: res.data.data,
          listArr:res.data.data ,
          noticeText: res.data.notice || "默认公告内容"
        })
      },
      fail: err => {
        console.error('数据加载失败', err);
        this.setData({ noticeText: "数据加载失败，请检查网络" });
      }
    })
//         wx.request({
//            url:host+indexUrl,
//            success:(res)=>{
//             console.log('列表数据',res.data);
//              this.setData({
//                listArr:res.data.data
//              })
//            }
//          }) 
wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] })
  },
  // 搜索处理
  handleSearch(e) {
    const keyword = e.detail.value.toLowerCase()
    const filtered = this.data.originalList.filter(item => 
      item.title.toLowerCase().includes(keyword) || 
      item.desc.toLowerCase().includes(keyword)
    )
    
    this.setData({
      searchText: keyword,
      listArr: keyword ? filtered : this.data.originalList
    })
  },

  // 清空搜索
  clearSearch() {
    this.setData({
      searchText: '',
      listArr: this.data.originalList
    })
  },

  navigateToDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/searchad/searchad?id=${id}`
    })
  },
//点击复制---------
// copy(e){
//  console.log(e.currentTarget.dataset.text);
//   wx.setClipboardData({//复制文本
//    data: e.currentTarget.dataset.text,
//    success: function (res) {
//       wx.getClipboardData({//获取复制文本//
 //        success: function (res) {
//          wx.showToast({
//            title:'复制成功',
//             icon:"none",//是否需要icon
 //            mask:"ture",//是否设置点击蒙版，防止点击穿透
 //           duration: 2000
//          })
//        }
//       })
//     }
//   })
// },
//------------------
//点击弹出是否观看广告弹窗
// handleShowAll:function(){
//   console.log('完整观看视频后可以查看内容')
//   wx.showModal({
//     title: ' ⚠️指尖看工具⚠️',
//     content: '完整观看视频后可以查看内容',
//     showCancel: true,
//     confirmText: '观看',
//     success: (res) => {
//       if (res.confirm) {
//         console.log('用户点击观看')
//   // 用户触发广告后，显示激励视频广告
//   if (this.videoAd) {
//     this.videoAd.show().catch(() => {
//       // 失败重试
//       this.videoAd.load()
//         .then(() => this.videoAd.show())
//         .catch(err => {
//           console.error('激励视频 广告显示失败', err)
//         })
//     })
//   }
      
//       }else if(res.cancel){
//         console.log('用户取消了观看')
//       }
//     }

//   })
// },
handleShowAll:function(){
  console.log('完整观看视频后可以查看全部内容')
  wx.showModal({
    title: ' ⚠️指尖看工具⚠️',
    content: '完整观看视频后可以查看全部内容',
    showCancel: true,
    confirmText: '观看',
    success: (res) => {
      if (res.confirm) {
        console.log('用户点击观看')
  // 用户触发广告后，显示激励视频广告
  if (this.videoAd) {
    this.videoAd.show().catch(() => {
      // 失败重试
      this.videoAd.load()
        .then(() => this.videoAd.show())
        .catch(err => {
          console.error('激励视频 广告显示失败', err)
        })
    })
  }
      
      }else if(res.cancel){
        console.log('用户取消了观看')
      }
    }

  })
},

//*---------------------------------*//

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    var that = this;
    // 动态获取屏幕高度
    wx.getSystemInfo({
      success: (result) => {
        that.setData({
          height: result.windowHeight
        });
      },
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})