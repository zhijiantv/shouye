// detail.js
//导入外部的模块js
const {host,searchUrl}=require('../../components/config')
const app=getApp()
Page({

  data: {
    detailData: null,
// 新增广告相关状态（独立状态树）
ad: null,
isUnlocked: false,
showSecretModal: false
},

  onLoad(options) {
    this.loadDetailData(options.id)
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },

// detail.js 修改后代码
loadDetailData(id) {
  wx.request({
    url: host+searchUrl,
    success: res => {
      const detail = res.data.data.find(item => item.id == id) || {}; // 找不到则返回空对象
      this.setData({ detailData: detail });
    }
  });
},

  onReady() {
    this.initAd()
  },

   // 新增广告逻辑（独立模块）
   initAd() {
    const ad = wx.createRewardedVideoAd({
      adUnitId: 'adunit-4a3f07fffad263f5'
    })

    ad.onLoad(() => console.log('广告加载完成'))
    ad.onError(err => {
      console.error('广告错误:', err)
      wx.showToast({ title: '广告加载失败', icon: 'none' })
    })

    ad.onClose(res => {
      if (res && res.isEnded) {
        this.handleAdSuccess()
      } else {
        wx.showToast({ title: '未完整观看', icon: 'none' })
      }
    })

    this.setData({ ad })
  },

  showAdConfirm() {
    wx.showModal({
      title: '观看广告提示',
      content: '观看30秒广告即可解锁隐藏内容',
      confirmText: '立即观看',
      success: res => {
        if (res.confirm) {
          this.data.ad.show().catch(() => {
            this.data.ad.load().then(() => this.data.ad.show())
          })
        }
      }
    })
  },

  handleAdSuccess() {
    this.setData({ 
      isUnlocked: true,
      showSecretModal: true 
    })
    
    // 记录广告观看状态（可选）
    wx.setStorageSync('unlocked_' + this.data.detailData.id, true)
  },

  copySecret() {
    wx.setClipboardData({
      data: this.data.detailData.text,
      success: () => {
        wx.showToast({ title: '复制成功' })
        this.setData({ showSecretModal: false })
      }
    })
  },

//*---------------------------------*//

})