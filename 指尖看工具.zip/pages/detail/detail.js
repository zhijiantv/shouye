const {host,localDataUrl}=require('../../components/config')
const app=getApp()

Page({
  data: {
    currentType: '',
    currentList: [],
    listData:{},
    ads:{},
  }
,
onLoad(options) {

      //二、列表数据
      wx.request({
        url: host+localDataUrl,
        success: res => {
          this.setData({ 
            listData: res.data.listData,                   //列表数据
            ads: res.data.ads,                             //广告数据

          })
        },
        fail: err => {
          console.error('数据加载失败', err);
          this.setData({ noticeText: "数据加载失败，请检查网络" });
        }
      })
      //二、列表数据
  // 解码并解析数据
  const decodedData = decodeURIComponent(options.data);
  const currentList = JSON.parse(decodedData);
  
  this.setData({
    currentList,
    pageType: options.type // 如果需要显示类型标题
  });
  wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
},

navigateToDetail(e) {
  const id = e.currentTarget.dataset.id; // 获取点击的id（如101）
    const adsData = this.data.ads[id]; // 从全局获取广告数据
    
    // 编码广告数据
    const encodedAds = encodeURIComponent(JSON.stringify(adsData));
    wx.navigateTo({
      url: `/pages/idload/idload?ads=${encodedAds}`,
    });
  },

   //*---------------------------------*//自定义导航栏
   handlerGobackClick(delta) {
    const pages = getCurrentPages();
    if (pages.length >= 2) {
      wx.navigateBack({
        delta: delta
      });
    } else {
      wx.navigateTo({
        url: '/pages/index/index'
      });
    }
  },
  handlerGohomeClick() {
    wx.navigateTo({
      url: '/pages/index/index'
    });
  }

})