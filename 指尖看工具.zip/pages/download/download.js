
Page({
  data: {
    wallpaperUrl: '',
  },

  onLoad(options) {
    this.setData({
      wallpaperUrl: decodeURIComponent(options.url)
    })
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });

  },

  navigateBack() {
    wx.navigateBack()
  },

// 保存壁纸功能
saveWallpaper() {
  const that = this;
  
  // 第一步：下载前确认提示
  wx.showModal({
    title: '保存提示',
    content: '即将保存壁纸到手机相册,\n需要访问相册权限',
    success(res) {
      if (res.confirm) {
        // 用户确认后开始流程
        that.checkAndSave();
      }
    }
  })
},

// 权限检查与保存流程
checkAndSave() {
  const that = this;
  
  // 显示加载提示
  wx.showLoading({
    title: '准备保存中...',
    mask: true
  });

  // 第一步：检查权限状态
  wx.getSetting({
    success(res) {
      if (!res.authSetting['scope.writePhotosAlbum']) {
        // 未授权时请求权限
        wx.authorize({
          scope: 'scope.writePhotosAlbum',
          success() {
            that.downloadAndSave();
          },
          fail() {
            wx.hideLoading();
            that.showAuthGuide();
          }
        })
      } else {
        // 已授权直接保存
        that.downloadAndSave();
      }
    }
  })
},

// 下载并保存图片
downloadAndSave() {
  const that = this;
  
  // 第二步：下载网络图片
  wx.downloadFile({
    url: this.data.wallpaperUrl,
    success(res) {
      if (res.statusCode === 200) {
        // 第三步：保存到相册
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success() {
            wx.hideLoading();
            wx.showToast({
              title: '壁纸保存成功',
              icon: 'success',
              duration: 2000
            });
          },
          fail(err) {
            wx.hideLoading();
            that.handleSaveError(err);
          }
        })
      }
    },
    fail(err) {
      wx.hideLoading();
      wx.showToast({
        title: '下载失败，请检查网络',
        icon: 'none'
      });
      console.error('下载失败:', err);
    }
  })
},

// 权限引导处理
showAuthGuide() {
  wx.showModal({
    title: '需要相册权限',
    content: '请在设置中开启相册权限',
    showCancel: false,
    success(res) {
      if (res.confirm) {
        wx.openSetting({
          success(settingRes) {
            if (settingRes.authSetting['scope.writePhotosAlbum']) {
              that.downloadAndSave();
            }
          }
        })
      }
    }
  })
},

// 错误统一处理
handleSaveError(err) {
  console.error('保存失败:', err);
  let msg = '保存失败，请重试';
  
  if (err.errMsg.includes('auth deny')) {
    msg = '未获得相册权限';
  } else if (err.errMsg.includes('tempFilePath')) {
    msg = '图片格式异常';
  }
  
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 2000
  });
},
  onShareAppMessage() {
    return {
      title: '超美壁纸分享',
      path: `/pages/wallpaper/detail?id=${this.data.id}`,
      imageUrl: this.data.wallpaperUrl
    };
  },
  onShareTimeline() {
    return { title: '点击获取同款壁纸！', query: `id=${this.data.id}` };
  },

  //*---------------------------------*//

})