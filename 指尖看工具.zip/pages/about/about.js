// pages/my/my3.js
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    login: {
      show: false,
      line: false,
      avatar: '../../images/zhijian.jpg',
    } 
  },
 
// 登录监听
chooseAvatar(e) {
  this.setData({
    login: {
      show: true,
      line:true,
      avatar: e.detail.avatarUrl,
    }
  })
},
 
// 基本信息
basicClick() {
  console.log('基本信息监听');
},
 
 // 匿名反馈
 feedbackClick() {
  console.log('匿名反馈监听');
},
// 关于我们
aboutClick() {
  console.log('关于我们监听');
  wx.navigateTo({
    url: '../aboutlist/aboutlist'
})

},
 
// 退出监听
exitClick() {
  let that = this;
  wx.showModal({
    title: '提示',
    content: '确定退出登录吗？',
    success(res) {
      if (res.confirm) {
        that.setData({
          login: {
            show: false,
            avatar: '../../images/zhijian.jpg',
          }
        })
      }
    }
  })
},
 
 
 
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
 
  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
 
  },
 
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
 
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
 
  },
 
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
 
  },
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
 
  },
 
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
 
  },
 
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
 
  },


//*点击按钮出现弹窗，弹窗内实现复制效果*//
basicClick:function(){    
  console.log("弹窗")
  const title = '⚠️指尖发布页⚠️'
  const content = 'https://link3.cc/zhijianTV'
  wx.showModal({
    title: title,
    content: content,
    showCancel: true,
    confirmText: '复制',
    success: (res) => {
      if (res.confirm) {
        console.log('用户点击复制')
        wx.setClipboardData({
          data: content,
          success: (res) => {
            wx.showToast({
              title: '已复制成功',
            })
          }
        })
      }else if(res.cancel){
        console.log('用户取消了复制')
      }
    }

  })
}
//*---------------------------------*//
}) 