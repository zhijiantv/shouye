// pages/idload/idload.js

Page({
  data: {
    adData: {},
    animationData: {},
    // 新增广告相关状态（独立状态树）
    ad: null,
    showAdButton: true
  },

  onLoad(options) {

    // 检查本地存储的解锁状态
const isUnlocked = wx.getStorageSync('isUnlocked');
if (isUnlocked) {
  this.setData({ isUnlocked });
}
// 初始化激励视频广告
this.initRewardedVideo();


    const decodedAds = decodeURIComponent(options.ads);
    const adInfo = JSON.parse(decodedAds);
    
    this.setData({
      adData: adInfo
    });
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },

// 初始化激励视频广告
initRewardedVideo() {
  const ad = wx.createRewardedVideoAd({
    adUnitId: 'adunit-4a3f07fffad263f5'
  });

  ad.onLoad(() => {
    console.log('广告加载成功');
  });

  ad.onError(err => {
    console.error('广告加载失败', err);
    wx.showToast({
      title: '广告加载失败，请重试',
      icon: 'none'
    });
  });

  ad.onClose(res => {
    // 广告关闭回调
    if (res && res.isEnded) {
      // 完整观看，解锁内容
      this.setData({ isUnlocked: true });
      wx.setStorageSync('isUnlocked', true);
      this.showModalAnimation();
    } else {
      // 未完整观看
      wx.showToast({
        title: '需完整观看广告才能解锁',
        icon: 'none'
      });
    }
  });

  this.setData({ ad });
},

// 显示广告弹窗
showAdModal() {
  this.data.ad.show().catch(() => {
    // 失败处理
    this.data.ad.load().then(() => this.data.ad.show());
  });
},

// 显示弹窗动画
showModalAnimation() {
  const animation = wx.createAnimation({
    duration: 300,
    timingFunction: 'ease-in-out'
  });

  animation.translateY(0).opacity(1).step();
  this.setData({
    animationData: animation.export(),
    showAdButton: false
  });
},
 // 显示弹窗
/*  showAdModal() {
  const animation = wx.createAnimation({
    duration: 300,
    timingFunction: 'ease-in-out'
  })
  animation.translateY(0).step()
  this.setData({
    showAdButton: false,
    animationData: animation.export()
  })
}, */


// 复制功能
handleCopy(e) {
  const link = e.currentTarget.dataset.link
  wx.setClipboardData({
    data: link,
    success: () => {
      wx.showToast({
        title: '复制成功',
        icon: 'success',
        duration: 1500,
        mask: true
      })
    }
  })
}
})