const {host,localDataUrl}=require('../../components/config')
const app=getApp()

Page({
  data: {
    swiperList: [],       // 轮播图数据
    sentence: "",         // 句子
    btnList: [],          // 按钮列表
    listData: {},         // 分类数据
    ads: {},               // 广告数据
    notices: [],          // 公告
    wallpaperList: []     // 壁纸列表
  },
  onLoad() {
    wx.request({
      url: host+localDataUrl,
      success: res => {
        this.setData({ 
          swiperList: res.data.swiperList,
          sentence: res.data.sentence,
          btnList: res.data.btnList,
          listData: res.data.listData,
          ads: res.data.ads,
          notices: res.data.notices,
          wallpaperList: res.data.wallpaperList,
        });
        console.log('轮播图:', res.data.swiperList);
        console.log('一言:', res.data.sentence);
        console.log('按钮:', res.data.btnList);
        console.log('列表:', res.data.listData);
        console.log('广告:', res.data.ads);
        console.log('公告:', res.data.notices);
        console.log('壁纸:', res.data.wallpaperList);
      },
      fail: err => {
        console.error('数据加载失败', err);
      }
    });
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },

// 搜索功能
searchbnutton() {
  wx.navigateTo({
    url: `/pages/search/search`
  })
},

// 按钮功能 
  onButtonClick(e) {
    const { id, type } = e.currentTarget.dataset;
    const selectedData = this.data.listData[type]; // 获取对应类型的数据
    
    // 将数据转为 JSON 字符串并编码（防止特殊字符问题）
    const encodedData = encodeURIComponent(JSON.stringify(selectedData));
    
    wx.navigateTo({
      url: `/pages/detail/detail?data=${encodedData}&type=${type}`,
    });
  },

  navigateToDownload(e) {
    const url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: `/pages/download/download?url=${encodeURIComponent(url)}`
    })
  }
})