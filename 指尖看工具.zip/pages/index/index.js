// pages/index/index.js
//导入外部的模块js
const {host,bannerUrl,idUrl}=require('../../common/config')
const app=getApp()
// 在页面中定义激励视频广告

Page({
  //全局广告设置
  videoAd:null,
  /**
   * 页面的初始数据
   */
  data: {
     height:'',//屏幕高度
     showPopup: false,
     currentIndex:0,
     bannerArr:[],//轮播数据
     listArr:[],//列表数据
  },

 
  //点击列表进行跳转页面

    //1.swiper轮播触发---
    swiperChange(e){
       
    //修改data值
    this.setData({
      currentIndex:e.detail.current 
    })
    },

  /**
   * 生命周期函数--监听页面加载
   */
  //封装小程序网络请求--------
//  http(url,arr){
//    wx.request({
//      url:url,
//     success:(res)=>{
//        console.log(res.data);
//          this.setData({
//            [arr]:res.data.data
//          })
//        }         
//    })
//  },
  onLoad:function(options) {
   // 在页面onLoad回调事件中创建激励视频广告实例
   if (wx.createRewardedVideoAd) {
    this.videoAd = wx.createRewardedVideoAd({
      adUnitId: 'adunit-4a3f07fffad263f5'
    })
    this.videoAd.onLoad(() => {})
    this.videoAd.onError((err) => {
      console.error('激励视频光告加载失败', err)
    })
    this.videoAd.onClose((res) => {
          console.log(res.isEnded)
      if(res.isEnded){
        this.setData({
          showPopup: true,
        })
       }else{
        wx.showToast({
          title:'无法获取',
   })
      }
  })
  }
  
    //2.请求网络数据轮播图-------
   // this.http(host+bannerUrl,'bannerArr')
   //获取app.js封装的网络请求------------
   app.http(host+bannerUrl,this,'bannerArr')
//     wx.request({
//    url:host+bannerUrl,
//      success:(res)=>{
//         console.log(res.data);
//           this.setData({
//             bannerUrl:res.data.data
//           })
//         }         
//      })

          //3.首页列表数据----------
     //this.http(host+indexUrl,'listArr')

     wx.request({
      url: host+idUrl,
      success: res => {
        this.setData({ listArr:res.data.data })
      },
      fail: err => {
        console.error('数据加载失败', err)
      }
    })
//         wx.request({
//            url:host+indexUrl,
//            success:(res)=>{
//             console.log('列表数据',res.data);
//              this.setData({
//                listArr:res.data.data
//              })
//            }
//          }) 

  },


  navigateToDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    })
  },
//点击复制---------
// copy(e){
//  console.log(e.currentTarget.dataset.text);
//   wx.setClipboardData({//复制文本
//    data: e.currentTarget.dataset.text,
//    success: function (res) {
//       wx.getClipboardData({//获取复制文本//
 //        success: function (res) {
//          wx.showToast({
//            title:'复制成功',
//             icon:"none",//是否需要icon
 //            mask:"ture",//是否设置点击蒙版，防止点击穿透
 //           duration: 2000
//          })
//        }
//       })
//     }
//   })
// },
//------------------
//点击弹出是否观看广告弹窗
// handleShowAll:function(){
//   console.log('完整观看视频后可以查看内容')
//   wx.showModal({
//     title: ' ⚠️指尖看工具⚠️',
//     content: '完整观看视频后可以查看内容',
//     showCancel: true,
//     confirmText: '观看',
//     success: (res) => {
//       if (res.confirm) {
//         console.log('用户点击观看')
//   // 用户触发广告后，显示激励视频广告
//   if (this.videoAd) {
//     this.videoAd.show().catch(() => {
//       // 失败重试
//       this.videoAd.load()
//         .then(() => this.videoAd.show())
//         .catch(err => {
//           console.error('激励视频 广告显示失败', err)
//         })
//     })
//   }
      
//       }else if(res.cancel){
//         console.log('用户取消了观看')
//       }
//     }

//   })
// },
handleShowAll:function(){
  console.log('完整观看视频后可以查看全部内容')
  wx.showModal({
    title: ' ⚠️指尖看工具⚠️',
    content: '完整观看视频后可以查看全部内容',
    showCancel: true,
    confirmText: '观看',
    success: (res) => {
      if (res.confirm) {
        console.log('用户点击观看')
  // 用户触发广告后，显示激励视频广告
  if (this.videoAd) {
    this.videoAd.show().catch(() => {
      // 失败重试
      this.videoAd.load()
        .then(() => this.videoAd.show())
        .catch(err => {
          console.error('激励视频 广告显示失败', err)
        })
    })
  }
      
      }else if(res.cancel){
        console.log('用户取消了观看')
      }
    }

  })
},
//*点击跳转页面显示数据*//
livelist:function(){
  console.log('直播接口');
  wx.navigateTo({
    url: '../livelist/livelist'
  })
},
jiekoulist:function(){
  console.log('影视接口');
  wx.navigateTo({
    url: '../jiekoulist/jiekoulist'
  })
},

//*点击按钮关闭弹窗*//
closePopup:function(){ 
  this.setData({
     showPopup:false
  })
 },
//*点击按钮出现弹窗，弹窗内实现复制效果*//
onCopy:function(e){    
    console.log(e.currentTarget.dataset.text)
    wx.showModal({
      title: ' ⚠️指尖看工具⚠️',
      content: e.currentTarget.dataset.text,
      showCancel: true,
      confirmText: '复制',
      success: (res) => {
        if (res.confirm) {
          console.log('用户点击复制')
          wx.setClipboardData({
            data: e.currentTarget.dataset.text,
            success: (res) => {
              wx.showToast({
                title: '已复制成功',
              })
            }
          })
        }else if(res.cancel){
          console.log('用户取消了复制')
        }
      }

    })
  },
//*---------------------------------*//

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    var that = this;
    // 动态获取屏幕高度
    wx.getSystemInfo({
      success: (result) => {
        that.setData({
          height: result.windowHeight
        });
      },
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})