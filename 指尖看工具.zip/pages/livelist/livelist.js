// pages/jiekoulist/jiekoulist.js
//导入外部的模块js
const {host,livelistUrl}=require('../../common/config')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

    listArr:[],//列表数据

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    app.http(host+livelistUrl,this,'listArr')
  },


  newShowModal:function(e){    
    console.log(e.currentTarget.dataset.text)
    wx.showModal({
      title: ' ⚠️指尖看工具⚠️',
      content: e.currentTarget.dataset.text,
      showCancel: true,
      confirmText: '复制',
      success: (res) => {
        if (res.confirm) {
          console.log('用户点击复制')
          wx.setClipboardData({
            data: e.currentTarget.dataset.text,
            success: (res) => {
              wx.showToast({
                title: '已复制成功',
              })
            }
          })
        }else if(res.cancel){
          console.log('用户取消了复制')
        }
      }

    })
  },
//*---------------------------------*//
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})