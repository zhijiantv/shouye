//公共的接口地址
module.exports={
    host:'https://kangj.netlify.app/',
    bannerUrl:'/lunbo.json',//轮播接口
    idUrl:'/list.json',//首页列表接口
    jiekoulistUrl:'/jiekoulist.json',//首页jiekou接口
    livelistUrl:'/livelist.json',//首页live接
//    indexDetail:'/id/1001',//首页详情数据
   
}
